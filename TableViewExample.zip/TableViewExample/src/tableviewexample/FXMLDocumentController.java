/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tableviewexample;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 *
 * @author Ahmad Wael
 */
public class FXMLDocumentController implements Initializable {
    
    



    
    @FXML
    private TableView<Person> table;

    @FXML
    private TableColumn<Person, Integer> id;

    @FXML
    private TableColumn<Person, String> movie;

    @FXML
    private TableColumn<Person, String> duration;

    @FXML
    private TableColumn<Person, String> adult;

    @FXML
    private TableColumn<Person, String> kids;

    @FXML
    private TableColumn<Person, String> start;

    @FXML
    private TableColumn<Person, String> end;
    @FXML
    private TableColumn<Person, String> hall;
    
    
    ObservableList<Person> list= FXCollections.observableArrayList(
    
    new Person(1, "Creed", "2 hours", "2000 HUF" , "500 HUF", "12:30","14:30","HALL 3"),
    new Person(2, "Neon Demon", "3 hours", "2500 HUF" , "700 HUF", "12:30","15:30","HALL 1"),
    new Person(3, "Baby Driver", "2 hours", "2000 HUF" , "500 HUF", "14:45","16:45","HALL 3"),
    new Person(4, "Black Panther", "2.5 hours", "2300 HUF" , "600 HUF", "12:30","15:00","HALL 2"),
    new Person(5, "HITMAN", "2 hours", "2000 HUF" , "500 HUF", "12:30","14:30","HALL 5")
            
    );
            
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        id.setCellValueFactory(new PropertyValueFactory<Person,Integer>("id"));
        movie.setCellValueFactory(new PropertyValueFactory<Person,String>("movie"));
        duration.setCellValueFactory(new PropertyValueFactory<Person,String>("duration"));
        adult.setCellValueFactory(new PropertyValueFactory<Person,String>("adult"));
        kids.setCellValueFactory(new PropertyValueFactory<Person,String>("kids"));
        start.setCellValueFactory(new PropertyValueFactory<Person,String>("start"));
        end.setCellValueFactory(new PropertyValueFactory<Person,String>("end"));
        hall.setCellValueFactory(new PropertyValueFactory<Person,String>("hall"));
        
        table.setItems(list);
        
        
        
        
    }    
    
}
